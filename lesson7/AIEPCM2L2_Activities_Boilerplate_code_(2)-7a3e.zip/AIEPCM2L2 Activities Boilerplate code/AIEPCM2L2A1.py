# Color Conversions and Cropping


# Convert BGR to RGB


# Convert to Grayscale

# Cropping the image
# Assume we know the region we want: rows 100 to 300, columns 200 to 400

