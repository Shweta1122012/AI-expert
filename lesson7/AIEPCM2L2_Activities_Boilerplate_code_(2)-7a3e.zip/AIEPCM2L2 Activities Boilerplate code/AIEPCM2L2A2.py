#  Rotating and Adjusting Brightness

# Rotate the image by 45 degrees around its center
  # rotate by 45 degrees

# Increase brightness by adding 50 to all pixel values
# Use cv2.add to avoid negative values or overflow
